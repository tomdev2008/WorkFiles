package magick;

public interface ClassType {

    public final static int UndefinedClass = 0;
    public final static int DirectClass = 1;
    public final static int PseudoClass = 2;
}
